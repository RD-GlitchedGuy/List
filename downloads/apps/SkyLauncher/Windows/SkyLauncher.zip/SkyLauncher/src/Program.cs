// =====================================================================
//   SKY LAUNCHER  –  Spiele-Bibliothek von GitHub laden und spielen
// =====================================================================
//
//   >>> HIER DEINE LIB EINTRAGEN <<<
//
//   Jeder Ordner oben im Repo = ein Spiel (Ordnername = Spielname).
//   Im Ordner liegt das Spiel (index.html + CSS + JS + beliebige Unterordner).
//   Optional: cover.png / cover.jpg / icon.png im Spielordner = Vorschaubild.
//
namespace SkyLauncher
{
    static class Lib
    {
        public const string GITHUB_USER   = "RD-GlitchedGuy";   // dein GitHub-Name
        public const string GITHUB_REPO   = "SkyLauncherGameDownload";              // Name des Repos
        public const string GITHUB_BRANCH = "main";             // Branch
        public const string GITHUB_TOKEN  = "";                 // nur für private Repos, sonst leer lassen

        public const string APP_NAME = "Sky Launcher";
        public const int    PORT     = 47811;  // fester Port, damit Spielstände (localStorage) erhalten bleiben
    }
}
// =====================================================================
//   Ab hier musst du nichts mehr ändern.
// =====================================================================

namespace SkyLauncher
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Sockets;
    using System.Reflection;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    class Settings
    {
        public string User = Lib.GITHUB_USER, Repo = Lib.GITHUB_REPO, Branch = Lib.GITHUB_BRANCH, Token = Lib.GITHUB_TOKEN;
        static string Defaults { get { return Lib.GITHUB_USER + "/" + Lib.GITHUB_REPO + "@" + Lib.GITHUB_BRANCH; } }

        public static Settings Load()
        {
            var s = new Settings();
            try
            {
                var f = Path.Combine(App.DataDir, "config.json");
                if (!File.Exists(f)) return s;
                var d = (Dictionary<string, object>)MiniJson.Parse(File.ReadAllText(f));
                // Wenn oben im Code eine andere Lib eingetragen wurde, gewinnt der Code.
                if ((d.ContainsKey("defaults") ? d["defaults"] as string : "") != Defaults) return s;
                s.User = Str(d, "user", s.User); s.Repo = Str(d, "repo", s.Repo);
                s.Branch = Str(d, "branch", s.Branch); s.Token = Str(d, "token", s.Token);
            }
            catch { }
            return s;
        }
        static string Str(Dictionary<string, object> d, string k, string def)
        {
            object v; return d.TryGetValue(k, out v) && v is string ? ((string)v).Trim() : def;
        }
        public void Save()
        {
            var d = new Dictionary<string, object> { { "defaults", Defaults }, { "user", User }, { "repo", Repo }, { "branch", Branch }, { "token", Token } };
            File.WriteAllText(Path.Combine(App.DataDir, "config.json"), MiniJson.Serialize(d));
        }
    }

    class RemoteGame
    {
        public string Name, Sha, Entry, Cover;
        public long Size;
        public List<KeyValuePair<string, long>> Files = new List<KeyValuePair<string, long>>();
    }

    class Job
    {
        public string Game, Status = "queued", Error;
        public int Done, Total;
        public long Bytes, TotalBytes;
    }

    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            try { App.Run(args); }
            catch (Exception e)
            {
                var log = Path.Combine(Path.GetTempPath(), "SkyLauncher-Fehler.txt");
                try { File.WriteAllText(log, e.ToString()); } catch { }
                var inner = e; while (inner.InnerException != null) inner = inner.InnerException;
                try { MessageBox.Show(inner.GetType().Name + ": " + inner.Message + "\n\nDetails: " + log, Lib.APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error); }
                catch { Console.Error.WriteLine(e); }
            }
        }
    }

    // Kleiner JSON-Leser/-Schreiber, damit keine zusätzliche Windows-Bibliothek nötig ist
    static class MiniJson
    {
        public static object Parse(string s) { int i = 0; var v = Val(s, ref i); return v; }
        static void Ws(string s, ref int i) { while (i < s.Length && char.IsWhiteSpace(s[i])) i++; }
        static object Val(string s, ref int i)
        {
            Ws(s, ref i);
            if (i >= s.Length) throw new FormatException("JSON zu kurz");
            char c = s[i];
            if (c == '{')
            {
                var d = new Dictionary<string, object>(); i++; Ws(s, ref i);
                if (s[i] == '}') { i++; return d; }
                while (true)
                {
                    Ws(s, ref i); var k = Str(s, ref i); Ws(s, ref i); i++; // ':'
                    d[k] = Val(s, ref i); Ws(s, ref i);
                    if (s[i++] == '}') return d;
                }
            }
            if (c == '[')
            {
                var l = new List<object>(); i++; Ws(s, ref i);
                if (s[i] == ']') { i++; return l; }
                while (true) { l.Add(Val(s, ref i)); Ws(s, ref i); if (s[i++] == ']') return l; }
            }
            if (c == '"') return Str(s, ref i);
            if (s.Substring(i).StartsWith("true")) { i += 4; return true; }
            if (s.Substring(i, Math.Min(5, s.Length - i)).StartsWith("false")) { i += 5; return false; }
            if (s.Substring(i, Math.Min(4, s.Length - i)).StartsWith("null")) { i += 4; return null; }
            int st = i;
            while (i < s.Length && "+-0123456789.eE".IndexOf(s[i]) >= 0) i++;
            var num = s.Substring(st, i - st);
            long lv; if (long.TryParse(num, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, out lv)) return lv;
            return double.Parse(num, System.Globalization.CultureInfo.InvariantCulture);
        }
        static string Str(string s, ref int i)
        {
            var sb = new StringBuilder(); i++;
            while (s[i] != '"')
            {
                char c = s[i++];
                if (c != '\\') { sb.Append(c); continue; }
                char e = s[i++];
                switch (e)
                {
                    case 'n': sb.Append('\n'); break; case 't': sb.Append('\t'); break; case 'r': sb.Append('\r'); break;
                    case 'b': sb.Append('\b'); break; case 'f': sb.Append('\f'); break;
                    case 'u': sb.Append((char)Convert.ToInt32(s.Substring(i, 4), 16)); i += 4; break;
                    default: sb.Append(e); break;
                }
            }
            i++; return sb.ToString();
        }
        public static string Serialize(object o) { var sb = new StringBuilder(); W(sb, o); return sb.ToString(); }
        static void W(StringBuilder sb, object o)
        {
            if (o == null) { sb.Append("null"); return; }
            if (o is string)
            {
                sb.Append('"');
                foreach (char c in (string)o)
                {
                    if (c == '"') sb.Append("\\\""); else if (c == '\\') sb.Append("\\\\");
                    else if (c < 32 || c == '<' || c == '>') sb.Append("\\u").Append(((int)c).ToString("x4"));
                    else sb.Append(c);
                }
                sb.Append('"'); return;
            }
            if (o is bool) { sb.Append((bool)o ? "true" : "false"); return; }
            if (o is int || o is long) { sb.Append(Convert.ToInt64(o)); return; }
            if (o is double || o is float) { sb.Append(Convert.ToDouble(o).ToString(System.Globalization.CultureInfo.InvariantCulture)); return; }
            var d = o as IDictionary;
            if (d != null)
            {
                sb.Append('{'); bool first = true;
                foreach (DictionaryEntry e in d) { if (!first) sb.Append(','); first = false; W(sb, e.Key.ToString()); sb.Append(':'); W(sb, e.Value); }
                sb.Append('}'); return;
            }
            var en = o as IEnumerable;
            if (en != null) { sb.Append('['); bool first = true; foreach (var x in en) { if (!first) sb.Append(','); first = false; W(sb, x); } sb.Append(']'); return; }
            W(sb, o.ToString());
        }
    }

    static class App
    {
                public static string DataDir, GamesDir, MetaDir;
        public static Settings Cfg;
        public static string Key, ApiBase, RawBase;
        public static int Port;

        static readonly object Lk = new object();
        static List<RemoteGame> remote; static DateTime remoteAt = DateTime.MinValue; static string remoteError;
        static readonly Dictionary<string, Job> jobs = new Dictionary<string, Job>();
        static readonly Queue<string> queue = new Queue<string>();
        static readonly AutoResetEvent queueSignal = new AutoResetEvent(false);

        public static DateTime LastPing = DateTime.MinValue, ByeAt = DateTime.MinValue;
        static Process browser; static DateTime browserStart; static NotifyIcon tray;
        static Mutex mutex;

        public static void Run(string[] args)
        {
            Key = Guid.NewGuid().ToString("N");
            ApiBase = Environment.GetEnvironmentVariable("SKY_API_BASE") ?? "https://api.github.com";
            RawBase = Environment.GetEnvironmentVariable("SKY_RAW_BASE") ?? "https://raw.githubusercontent.com";
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; // TLS 1.2
            ServicePointManager.DefaultConnectionLimit = 16;
            bool headless = args.Contains("--headless");

            DataDir = Environment.GetEnvironmentVariable("SKY_DATA_DIR") ??
                      Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SkyLauncher");
            GamesDir = Path.Combine(DataDir, "games");
            MetaDir = Path.Combine(DataDir, "meta");
            Directory.CreateDirectory(GamesDir); Directory.CreateDirectory(MetaDir);
            Cfg = Settings.Load();

            bool first;
            mutex = new Mutex(true, "SkyLauncher_SingleInstance", out first);
            var sessionFile = Path.Combine(DataDir, "session.txt");
            if (!first && !headless)
            {
                // Läuft schon -> nur ein weiteres Fenster öffnen
                try { OpenBrowser(File.ReadAllText(sessionFile).Trim()); } catch { }
                return;
            }

            var listener = StartServer();
            var url = "http://127.0.0.1:" + Port + "/?k=" + Key;
            File.WriteAllText(sessionFile, url);
            new Thread(Worker) { IsBackground = true }.Start();
            ThreadPool.QueueUserWorkItem(_ => { try { GetRemote(false); } catch { } });

            if (headless)
            {
                Console.WriteLine("Sky Launcher läuft: " + url);
                Thread.Sleep(Timeout.Infinite);
            }

            browser = OpenBrowser(url);
            browserStart = DateTime.Now;
            SetupTray(url);
            var watch = new System.Windows.Forms.Timer { Interval = 1000 };
            watch.Tick += (s, e) => { if (ShouldExit()) Quit(); };
            watch.Start();
            Application.Run();
            listener.Stop();
        }

        static bool ShouldExit()
        {
            var now = DateTime.Now;
            bool procAlive = browser != null && !SafeExited(browser);
            bool procTracked = browser != null && (now - browserStart).TotalSeconds > 8;
            if (procTracked && !procAlive && (now - LastPing).TotalSeconds > 6) return true;
            if (ByeAt > LastPing && (now - ByeAt).TotalSeconds > 6 && !procAlive) return true;
            if (LastPing != DateTime.MinValue && (now - LastPing).TotalSeconds > 180) return true;
            return false;
        }
        static bool SafeExited(Process p) { try { return p.HasExited; } catch { return true; } }

        static void Quit()
        {
            if (tray != null) { tray.Visible = false; tray.Dispose(); }
            Application.Exit();
            Environment.Exit(0);
        }

        static void SetupTray(string url)
        {
            Icon ico = null;
            try { ico = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
            var menu = new ContextMenuStrip();
            menu.Items.Add("Bibliothek öffnen", null, (s, e) => OpenBrowser(url));
            menu.Items.Add("Spiele-Ordner öffnen", null, (s, e) => Process.Start("explorer.exe", "\"" + GamesDir + "\""));
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Beenden", null, (s, e) => Quit());
            tray = new NotifyIcon { Icon = ico ?? SystemIcons.Application, Text = Lib.APP_NAME, ContextMenuStrip = menu, Visible = true };
            tray.DoubleClick += (s, e) => OpenBrowser(url);
        }

        // ---------------------------------------------------------- Browser-Fenster
        static Process OpenBrowser(string url)
        {
            var pf86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            var pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var candidates = new[] {
                Path.Combine(pf86, @"Microsoft\Edge\Application\msedge.exe"),
                Path.Combine(pf,   @"Microsoft\Edge\Application\msedge.exe"),
                Path.Combine(pf,   @"Google\Chrome\Application\chrome.exe"),
                Path.Combine(pf86, @"Google\Chrome\Application\chrome.exe"),
                Path.Combine(local,@"Google\Chrome\Application\chrome.exe"),
                Path.Combine(pf,   @"BraveSoftware\Brave-Browser\Application\brave.exe"),
            };
            var exe = candidates.FirstOrDefault(File.Exists);
            if (exe != null)
            {
                var profile = Path.Combine(DataDir, "browser");
                var a = "--app=\"" + url + "\" --user-data-dir=\"" + profile + "\" --window-size=1360,820 " +
                        "--no-first-run --no-default-browser-check --autoplay-policy=no-user-gesture-required " +
                        "--disable-background-timer-throttling --disable-renderer-backgrounding " +
                        "--disable-backgrounding-occluded-windows --disable-features=Translate,msEdgeSidebar " +
                        "--disable-sync --edge-skip-compat-layer-relaunch";
                return Process.Start(new ProcessStartInfo(exe, a) { UseShellExecute = false });
            }
            try { Process.Start(url); } catch { }
            return null;
        }

        // ---------------------------------------------------------- GitHub
        static HttpWebRequest Req(string url, bool api)
        {
            var r = (HttpWebRequest)WebRequest.Create(url);
            r.UserAgent = "SkyLauncher";
            r.Timeout = 30000; r.ReadWriteTimeout = 60000;
            r.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            if (api) r.Accept = "application/vnd.github+json";
            if (!string.IsNullOrEmpty(Cfg.Token)) r.Headers["Authorization"] = "token " + Cfg.Token;
            return r;
        }

        static string Enc(string path)
        {
            return string.Join("/", path.Split('/').Select(Uri.EscapeDataString));
        }

        static List<RemoteGame> GetRemote(bool force)
        {
            lock (Lk)
            {
                if (!force && remote != null && (DateTime.Now - remoteAt).TotalSeconds < 120) return remote;
            }
            var c = Cfg;
            if (remote == null) LoadCache();
            var url = ApiBase + "/repos/" + Enc(c.User) + "/" + Enc(c.Repo) + "/git/trees/" + Enc(c.Branch) + "?recursive=1";
            try
            {
                string body, etag;
                var rq = Req(url, true);
                if (remote != null && cacheEtag != null && cacheKey == CacheKey()) rq.Headers["If-None-Match"] = cacheEtag;
                try
                {
                    using (var resp = (HttpWebResponse)rq.GetResponse())
                    using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) { body = sr.ReadToEnd(); etag = resp.Headers["ETag"]; }
                }
                catch (WebException nm)
                {
                    var nr = nm.Response as HttpWebResponse;
                    if (nr != null && nr.StatusCode == HttpStatusCode.NotModified)
                    {   // nichts geändert -> zählt nicht gegen das GitHub-Limit
                        lock (Lk) { remoteAt = DateTime.Now; remoteError = null; }
                        return remote;
                    }
                    throw;
                }
                var list = ParseTree(body, c);
                lock (Lk) { remote = list; remoteAt = DateTime.Now; remoteError = null; cacheEtag = etag; cacheKey = CacheKey(); }
                SaveCache(body, etag);
                return list;
            }
            catch (WebException we)
            {
                var r = we.Response as HttpWebResponse;
                string msg;
                if (r == null) msg = remote != null && remote.Count > 0 ? "Offline – zeige die zuletzt geladene Liste." : "Keine Verbindung zu GitHub. Installierte Spiele funktionieren trotzdem.";
                else if (r.StatusCode == HttpStatusCode.NotFound) msg = "Repo oder Branch nicht gefunden: " + c.User + "/" + c.Repo + " (" + c.Branch + "). Bei privaten Repos einen Token eintragen.";
                else if ((int)r.StatusCode == 403 || (int)r.StatusCode == 429) msg = "GitHub-Limit erreicht (60 Abfragen/Stunde ohne Token) – zeige die zuletzt geladene Liste.";
                else msg = "GitHub-Fehler " + (int)r.StatusCode + ".";
                lock (Lk) { remoteError = msg; }
                return remote ?? new List<RemoteGame>();
            }
            catch (Exception ex)
            {
                lock (Lk) { remoteError = "Fehler beim Laden der Liste: " + ex.Message; }
                return remote ?? new List<RemoteGame>();
            }
        }

        static string cacheEtag, cacheKey;
        static string CacheKey() { return (Cfg.User + "/" + Cfg.Repo + "@" + Cfg.Branch).ToLowerInvariant(); }
        static string CacheFile { get { return Path.Combine(DataDir, "liste-cache.json"); } }

        static void SaveCache(string body, string etag)
        {
            try { File.WriteAllText(CacheFile, MiniJson.Serialize(new Dictionary<string, object> { { "key", CacheKey() }, { "etag", etag }, { "body", body } })); } catch { }
        }

        static void LoadCache()
        {
            try
            {
                if (!File.Exists(CacheFile)) return;
                var d = (Dictionary<string, object>)MiniJson.Parse(File.ReadAllText(CacheFile));
                if ((d["key"] as string) != CacheKey()) return;
                var list = ParseTree((string)d["body"], Cfg);
                lock (Lk) { remote = list; cacheEtag = d["etag"] as string; cacheKey = CacheKey(); }
            }
            catch { }
        }

        static List<RemoteGame> ParseTree(string body, Settings c)
        {
                var root = (Dictionary<string, object>)MiniJson.Parse(body);
                var games = new Dictionary<string, RemoteGame>(StringComparer.Ordinal);
                var tree = (List<object>)root["tree"];
                foreach (Dictionary<string, object> e in tree)
                {
                    var p = (string)e["path"]; var type = (string)e["type"];
                    int slash = p.IndexOf('/');
                    if (slash < 0)
                    {
                        if (type == "tree" && !p.StartsWith(".") && !p.StartsWith("_"))
                            games[p] = new RemoteGame { Name = p, Sha = (string)e["sha"] };
                        continue;
                    }
                    if (type != "blob") continue;
                    RemoteGame g;
                    if (!games.TryGetValue(p.Substring(0, slash), out g)) continue;
                    long size = e.ContainsKey("size") ? Convert.ToInt64(e["size"]) : 0;
                    g.Files.Add(new KeyValuePair<string, long>(p.Substring(slash + 1), size));
                    g.Size += size;
                }
                var list = games.Values.Where(g => g.Files.Count > 0).OrderBy(g => g.Name, StringComparer.OrdinalIgnoreCase).ToList();
                foreach (var g in list)
                {
                    var names = g.Files.Select(f => f.Key).ToList();
                    g.Entry = FindEntry(names);
                    var cover = FindCover(names);
                    if (cover != null) g.Cover = RawBase + "/" + Enc(c.User) + "/" + Enc(c.Repo) + "/" + Enc(c.Branch) + "/" + Enc(g.Name + "/" + cover);
                }
                return list;
        }

        static string FindEntry(IEnumerable<string> files)
        {
            var l = files.ToList();
            var exact = l.FirstOrDefault(f => f.Equals("index.html", StringComparison.OrdinalIgnoreCase));
            if (exact != null) return exact;
            return l.Where(f => f.EndsWith(".html", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".htm", StringComparison.OrdinalIgnoreCase))
                    .OrderBy(f => f.Count(ch => ch == '/'))
                    .ThenBy(f => f.EndsWith("index.html", StringComparison.OrdinalIgnoreCase) ? 0 : 1)
                    .ThenBy(f => f.Length).FirstOrDefault();
        }

        static string FindCover(IEnumerable<string> files)
        {
            var l = files.ToList();
            foreach (var n in new[] { "cover", "preview", "thumbnail", "thumb", "icon", "logo", "screenshot" })
                foreach (var ext in new[] { ".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg" })
                {
                    var hit = l.FirstOrDefault(f => f.Equals(n + ext, StringComparison.OrdinalIgnoreCase));
                    if (hit != null) return hit;
                }
            return null;
        }

        // ---------------------------------------------------------- Installieren
        static string MetaSha(string game)
        {
            try
            {
                var d = (Dictionary<string, object>)MiniJson.Parse(File.ReadAllText(Path.Combine(MetaDir, game + ".json")));
                return d["sha"] as string;
            }
            catch { return null; }
        }

        static void Enqueue(string game)
        {
            lock (Lk)
            {
                Job j;
                if (jobs.TryGetValue(game, out j) && (j.Status == "queued" || j.Status == "running")) return;
                jobs[game] = new Job { Game = game };
                queue.Enqueue(game);
            }
            queueSignal.Set();
        }

        static void Worker()
        {
            while (true)
            {
                string game = null;
                lock (Lk) { if (queue.Count > 0) game = queue.Dequeue(); }
                if (game == null) { queueSignal.WaitOne(); continue; }
                Job job; lock (Lk) job = jobs[game];
                try { Install(job); job.Status = "done"; }
                catch (Exception e) { job.Status = "error"; job.Error = e.Message; }
            }
        }

        static void Install(Job job)
        {
            job.Status = "running";
            var g = GetRemote(true).FirstOrDefault(x => x.Name == job.Game);
            if (g == null) throw new Exception("Spiel nicht mehr im Repo gefunden.");
            job.Total = g.Files.Count; job.TotalBytes = g.Size;
            var c = Cfg;
            var tmp = Path.Combine(GamesDir, ".download_" + SafeName(g.Name));
            if (Directory.Exists(tmp)) Directory.Delete(tmp, true);
            Directory.CreateDirectory(tmp);
            string firstError = null;

            Parallel.ForEach(g.Files, new ParallelOptions { MaxDegreeOfParallelism = 6 }, (f, state) =>
            {
                if (firstError != null) { state.Stop(); return; }
                var url = RawBase + "/" + Enc(c.User) + "/" + Enc(c.Repo) + "/" + Enc(c.Branch) + "/" + Enc(g.Name + "/" + f.Key);
                var dest = Path.Combine(tmp, f.Key.Replace('/', Path.DirectorySeparatorChar));
                if (!Path.GetFullPath(dest).StartsWith(Path.GetFullPath(tmp))) return;
                Directory.CreateDirectory(Path.GetDirectoryName(dest));
                for (int attempt = 1; ; attempt++)
                {
                    try
                    {
                        long got = 0;
                        using (var resp = Req(url, false).GetResponse())
                        using (var src = resp.GetResponseStream())
                        using (var fs = File.Create(dest))
                        {
                            var buf = new byte[65536]; int n;
                            while ((n = src.Read(buf, 0, buf.Length)) > 0)
                            {
                                fs.Write(buf, 0, n); got += n;
                                Interlocked.Add(ref job.Bytes, n);
                            }
                        }
                        Interlocked.Increment(ref job.Done);
                        break;
                    }
                    catch (Exception e)
                    {
                        if (attempt >= 3) { firstError = "Download fehlgeschlagen: " + f.Key + " (" + e.Message + ")"; return; }
                        Thread.Sleep(600 * attempt);
                    }
                }
            });
            if (firstError != null) { TryDelete(tmp); throw new Exception(firstError); }

            var final = Path.Combine(GamesDir, SafeName(g.Name));
            if (Directory.Exists(final)) Directory.Delete(final, true);
            Directory.Move(tmp, final);
            File.WriteAllText(Path.Combine(MetaDir, SafeName(g.Name) + ".json"),
                MiniJson.Serialize(new Dictionary<string, object> { { "sha", g.Sha }, { "entry", g.Entry }, { "installed", DateTime.UtcNow.ToString("o") } }));
        }

        static void TryDelete(string dir) { try { if (Directory.Exists(dir)) Directory.Delete(dir, true); } catch { } }

        static string SafeName(string n)
        {
            foreach (var ch in Path.GetInvalidFileNameChars()) n = n.Replace(ch, '_');
            return n;
        }

        static object State(bool refresh)
        {
            var rem = GetRemote(refresh);
            var installed = Directory.GetDirectories(GamesDir).Select(Path.GetFileName).Where(n => !n.StartsWith(".")).ToList();
            var names = rem.Select(r => r.Name).Union(installed).OrderBy(n => n, StringComparer.OrdinalIgnoreCase);
            var games = new List<object>();
            foreach (var n in names)
            {
                var r = rem.FirstOrDefault(x => x.Name == n);
                bool inst = installed.Contains(n);
                string entry = null, cover = r != null ? r.Cover : null;
                if (inst)
                {
                    var dir = Path.Combine(GamesDir, n);
                    var files = Directory.GetFiles(dir, "*", SearchOption.AllDirectories)
                        .Select(f => f.Substring(dir.Length + 1).Replace('\\', '/')).ToList();
                    entry = FindEntry(files);
                    var lc = FindCover(files);
                    if (lc != null) cover = "/play/" + Enc(n) + "/" + Enc(lc);
                }
                Job j; lock (Lk) jobs.TryGetValue(n, out j);
                var sha = inst ? MetaSha(n) : null;
                games.Add(new Dictionary<string, object> {
                    { "name", n },
                    { "installed", inst },
                    { "remote", r != null },
                    { "update", inst && r != null && sha != null && sha != r.Sha },
                    { "size", r != null ? r.Size : 0 },
                    { "files", r != null ? r.Files.Count : 0 },
                    { "entry", entry },
                    { "playUrl", entry != null ? "/play/" + Enc(n) + "/" + Enc(entry) : null },
                    { "cover", cover },
                    { "job", j == null ? null : new Dictionary<string, object> {
                        { "status", j.Status }, { "error", j.Error }, { "done", j.Done }, { "total", j.Total },
                        { "bytes", j.Bytes }, { "totalBytes", j.TotalBytes } } }
                });
            }
            string err; lock (Lk) err = remoteError;
            return new Dictionary<string, object> {
                { "config", new Dictionary<string, object> { { "user", Cfg.User }, { "repo", Cfg.Repo }, { "branch", Cfg.Branch }, { "hasToken", !string.IsNullOrEmpty(Cfg.Token) } } },
                { "error", err }, { "games", games }, { "appName", Lib.APP_NAME }
            };
        }

        // ---------------------------------------------------------- Mini-Webserver
        static TcpListener StartServer()
        {
            for (int p = Lib.PORT; p < Lib.PORT + 20; p++)
            {
                try
                {
                    var l = new TcpListener(IPAddress.Loopback, p); l.Start();
                    Port = p;
                    new Thread(() => { while (true) { try { var c = l.AcceptTcpClient(); ThreadPool.QueueUserWorkItem(_ => Handle(c)); } catch { return; } } }) { IsBackground = true }.Start();
                    return l;
                }
                catch (SocketException) { }
            }
            throw new Exception("Kein freier Port gefunden.");
        }

        static void Handle(TcpClient client)
        {
            using (client)
            {
                try
                {
                    var ns = client.GetStream();
                    ns.ReadTimeout = 15000;
                    var head = new MemoryStream(); var buf = new byte[8192]; int end = -1; byte[] all = null;
                    while (end < 0)
                    {
                        int n = ns.Read(buf, 0, buf.Length);
                        if (n <= 0) return;
                        head.Write(buf, 0, n);
                        all = head.ToArray();
                        for (int i = Math.Max(0, all.Length - n - 3); i + 3 < all.Length; i++)
                            if (all[i] == 13 && all[i + 1] == 10 && all[i + 2] == 13 && all[i + 3] == 10) { end = i; break; }
                        if (all.Length > 65536) return;
                    }
                    var lines = Encoding.ASCII.GetString(all, 0, end).Split(new[] { "\r\n" }, StringSplitOptions.None);
                    var rl = lines[0].Split(' ');
                    if (rl.Length < 2) return;
                    string method = rl[0], target = rl[1];
                    var h = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    foreach (var ln in lines.Skip(1)) { int c = ln.IndexOf(':'); if (c > 0) h[ln.Substring(0, c).Trim()] = ln.Substring(c + 1).Trim(); }
                    var body = new MemoryStream();
                    body.Write(all, end + 4, all.Length - end - 4);
                    string cl; int len;
                    if (h.TryGetValue("Content-Length", out cl) && int.TryParse(cl, out len) && len < 1 << 20)
                        while (body.Length < len) { int n = ns.Read(buf, 0, buf.Length); if (n <= 0) break; body.Write(buf, 0, n); }

                    string host; h.TryGetValue("Host", out host);
                    if (host != "127.0.0.1:" + Port && host != "localhost:" + Port) { Send(ns, 403, "text/plain", "forbidden", method); return; }

                    string path = target, query = "";
                    int q = target.IndexOf('?'); if (q >= 0) { path = target.Substring(0, q); query = target.Substring(q + 1); }
                    Route(ns, method, path, query, h, Encoding.UTF8.GetString(body.ToArray()));
                }
                catch { }
            }
        }

        static string Q(string query, string key)
        {
            foreach (var part in query.Split('&'))
            {
                int e = part.IndexOf('=');
                if (e > 0 && part.Substring(0, e) == key) return Uri.UnescapeDataString(part.Substring(e + 1).Replace('+', ' '));
            }
            return null;
        }

        static void Route(NetworkStream ns, string method, string path, string query, Dictionary<string, string> h, string body)
        {
            if (path == "/" || path == "/index.html")
            {
                using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("ui.html"))
                using (var sr = new StreamReader(s)) Send(ns, 200, "text/html; charset=utf-8", sr.ReadToEnd(), method);
                return;
            }
            if (path == "/__sky/hook.js")
            {
                using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("hook.js"))
                using (var sr = new StreamReader(s)) Send(ns, 200, "text/javascript; charset=utf-8", sr.ReadToEnd(), method);
                return;
            }
            if (path == "/favicon.ico") { Send(ns, 204, "text/plain", "", method); return; }
            if (path.StartsWith("/play/")) { ServeFile(ns, method, path.Substring(6), h); return; }
            if (!path.StartsWith("/api/")) { Send(ns, 404, "text/plain", "Nicht gefunden", method); return; }

            string k; h.TryGetValue("X-Sky-Key", out k);
            if (k != Key && Q(query, "k") != Key) { Send(ns, 403, "application/json", "{\"error\":\"key\"}", method); return; }

            var api = path.Substring(5);
            var game = Q(query, "game");
            object result = new Dictionary<string, object> { { "ok", true } };
            switch (api)
            {
                case "ping": LastPing = DateTime.Now; break;
                case "bye": ByeAt = DateTime.Now; break;
                case "state": result = State(Q(query, "refresh") == "1"); break;
                case "install":
                    if (string.IsNullOrEmpty(game)) { result = Err("game fehlt"); break; }
                    Enqueue(game); break;
                case "delete":
                    if (string.IsNullOrEmpty(game) || game.Contains("..") || game.Contains("/") || game.Contains("\\")) { result = Err("ungültig"); break; }
                    TryDelete(Path.Combine(GamesDir, game));
                    try { File.Delete(Path.Combine(MetaDir, game + ".json")); } catch { }
                    lock (Lk) jobs.Remove(game);
                    break;
                case "folder":
                    var dir = GamesDir;
                    if (!string.IsNullOrEmpty(game) && !game.Contains("..") && Directory.Exists(Path.Combine(GamesDir, game))) dir = Path.Combine(GamesDir, game);
                    try { Process.Start("explorer.exe", "\"" + dir + "\""); } catch { }
                    break;
                case "config":
                    if (method == "POST")
                    {
                        var d = (Dictionary<string, object>)MiniJson.Parse(body);
                        var s = new Settings();
                        Func<string, string, string> get = (key, def) => { object v; return d.TryGetValue(key, out v) && v is string && ((string)v).Trim() != "" ? ((string)v).Trim() : def; };
                        s.User = get("user", Cfg.User);
                        s.Repo = get("repo", Cfg.Repo);
                        s.Branch = get("branch", "main");
                        s.Token = d.ContainsKey("token") ? (get("token", "")) : Cfg.Token;
                        if (s.Repo.Contains("/")) { var sp = s.Repo.Split('/'); s.User = sp[sp.Length - 2]; s.Repo = sp[sp.Length - 1]; }
                        Cfg = s; s.Save();
                        lock (Lk) { remote = null; remoteError = null; }
                    }
                    result = State(false);
                    break;
                default: Send(ns, 404, "application/json", "{\"error\":\"unbekannt\"}", method); return;
            }
            Send(ns, 200, "application/json; charset=utf-8", MiniJson.Serialize(result), method);
        }

        static object Err(string m) { return new Dictionary<string, object> { { "ok", false }, { "error", m } }; }

        static readonly Dictionary<string, string> Mime = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) {
            {".html","text/html; charset=utf-8"},{".htm","text/html; charset=utf-8"},{".css","text/css; charset=utf-8"},
            {".js","text/javascript; charset=utf-8"},{".mjs","text/javascript; charset=utf-8"},{".json","application/json; charset=utf-8"},
            {".map","application/json"},{".wasm","application/wasm"},{".txt","text/plain; charset=utf-8"},{".xml","application/xml"},
            {".svg","image/svg+xml"},{".png","image/png"},{".jpg","image/jpeg"},{".jpeg","image/jpeg"},{".gif","image/gif"},
            {".webp","image/webp"},{".ico","image/x-icon"},{".bmp","image/bmp"},{".avif","image/avif"},
            {".mp3","audio/mpeg"},{".ogg","audio/ogg"},{".oga","audio/ogg"},{".wav","audio/wav"},{".m4a","audio/mp4"},{".aac","audio/aac"},{".flac","audio/flac"},
            {".mp4","video/mp4"},{".webm","video/webm"},{".ogv","video/ogg"},
            {".ttf","font/ttf"},{".otf","font/otf"},{".woff","font/woff"},{".woff2","font/woff2"},
            {".glb","model/gltf-binary"},{".gltf","model/gltf+json"},{".obj","text/plain"},{".bin","application/octet-stream"},
            {".csv","text/csv"},{".frag","text/plain"},{".vert","text/plain"},{".glsl","text/plain"}
        };

        static void ServeFile(NetworkStream ns, string method, string rel, Dictionary<string, string> h)
        {
            var parts = rel.Split('/').Select(Uri.UnescapeDataString).ToArray();
            if (parts.Any(p => p == "..")) { Send(ns, 403, "text/plain", "forbidden", method); return; }
            var full = Path.GetFullPath(Path.Combine(GamesDir, Path.Combine(parts)));
            var rootFull = Path.GetFullPath(GamesDir) + Path.DirectorySeparatorChar;
            if (!full.StartsWith(rootFull, StringComparison.OrdinalIgnoreCase)) { Send(ns, 403, "text/plain", "forbidden", method); return; }
            if (Directory.Exists(full))
            {
                if (!rel.EndsWith("/")) { Redirect(ns, "/play/" + rel + "/"); return; }
                full = Path.Combine(full, "index.html");
            }
            if (!File.Exists(full)) { Send(ns, 404, "text/plain; charset=utf-8", "Datei nicht gefunden: " + rel, method); return; }

            string ct; if (!Mime.TryGetValue(Path.GetExtension(full), out ct)) ct = "application/octet-stream";
            if (ct.StartsWith("text/html"))
            {
                // kleinen Helfer fürs Overlay einschleusen (F9/F11, Stummschalten)
                var html = File.ReadAllText(full);
                const string tag = "<script src=\"/__sky/hook.js\"></script>";
                var m = System.Text.RegularExpressions.Regex.Match(html, @"<head[^>]*>", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                if (!m.Success) m = System.Text.RegularExpressions.Regex.Match(html, @"<html[^>]*>|<!doctype[^>]*>", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                html = m.Success ? html.Insert(m.Index + m.Length, tag) : tag + html;
                Send(ns, 200, ct, html, method);
                return;
            }
            using (var fs = new FileStream(full, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            {
                long total = fs.Length, start = 0, stop = total - 1; int status = 200;
                string range;
                if (h.TryGetValue("Range", out range) && range.StartsWith("bytes=") && total > 0)
                {
                    var r = range.Substring(6).Split(',')[0].Split('-');
                    long a, b;
                    if (r[0] == "" && long.TryParse(r[1], out b)) { start = Math.Max(0, total - b); }
                    else if (long.TryParse(r[0], out a)) { start = a; if (r.Length > 1 && long.TryParse(r[1], out b)) stop = Math.Min(b, total - 1); }
                    if (start > stop || start >= total)
                    {
                        WriteHead(ns, 416, ct, 0, "Content-Range: bytes */" + total + "\r\n"); return;
                    }
                    status = 206;
                }
                long count = total == 0 ? 0 : stop - start + 1;
                WriteHead(ns, status, ct, count, "Accept-Ranges: bytes\r\nCache-Control: no-cache\r\n" +
                    (status == 206 ? "Content-Range: bytes " + start + "-" + stop + "/" + total + "\r\n" : ""));
                if (method == "HEAD") return;
                fs.Seek(start, SeekOrigin.Begin);
                var buf = new byte[65536];
                while (count > 0)
                {
                    int n = fs.Read(buf, 0, (int)Math.Min(buf.Length, count));
                    if (n <= 0) break;
                    ns.Write(buf, 0, n); count -= n;
                }
            }
        }

        static string Reason(int s)
        {
            switch (s) { case 200: return "OK"; case 204: return "No Content"; case 206: return "Partial Content"; case 302: return "Found"; case 403: return "Forbidden"; case 404: return "Not Found"; case 416: return "Range Not Satisfiable"; default: return "OK"; }
        }

        static void WriteHead(NetworkStream ns, int status, string ct, long len, string extra)
        {
            var sb = "HTTP/1.1 " + status + " " + Reason(status) + "\r\nContent-Type: " + ct + "\r\nContent-Length: " + len +
                     "\r\nConnection: close\r\nX-Content-Type-Options: nosniff\r\n" + extra + "\r\n";
            var b = Encoding.ASCII.GetBytes(sb); ns.Write(b, 0, b.Length);
        }

        static void Send(NetworkStream ns, int status, string ct, string body, string method)
        {
            var b = Encoding.UTF8.GetBytes(body);
            WriteHead(ns, status, ct, b.Length, "Cache-Control: no-store\r\n");
            if (method != "HEAD") ns.Write(b, 0, b.Length);
        }

        static void Redirect(NetworkStream ns, string loc)
        {
            WriteHead(ns, 302, "text/plain", 0, "Location: " + loc + "\r\n");
        }
    }
}
