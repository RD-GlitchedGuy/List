@echo off
rem Baut SkyLauncher.exe neu - nutzt den C#-Compiler, der in Windows schon drin ist.
cd /d "%~dp0"
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
"%CSC%" /nologo /target:winexe /optimize+ /win32icon:icon.ico /resource:ui.html,ui.html /resource:hook.js,hook.js ^
  /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Core.dll ^
  /out:..\SkyLauncher.exe Program.cs
if errorlevel 1 (echo. & echo FEHLER beim Bauen & pause & exit /b 1)
echo Fertig: ..\SkyLauncher.exe
pause
