(function () {
  if (window.__sky || window.parent === window) return; window.__sky = 1;
  var muted = false, ctxs = [];
  ["AudioContext", "webkitAudioContext"].forEach(function (n) {
    var C = window[n]; if (!C || C.__sky) return;
    var resume = C.prototype.resume;
    C.prototype.resume = function () { return muted ? Promise.resolve() : resume.call(this); };
    var W = class extends C { constructor(a) { super(a); ctxs.push(this); if (muted) this.suspend(); } };
    W.__sky = 1; W.__resume = resume; window[n] = W;
  });
  function media(m) { document.querySelectorAll("audio,video").forEach(function (a) { a.muted = m; }); }
  document.addEventListener("play", function (e) { if (muted && e.target) e.target.muted = true; }, true);
  var _Audio = window.Audio;
  if (_Audio) window.Audio = function (src) { var a = new _Audio(src); if (muted) a.muted = true; all.push(a); return a; };
  if (_Audio) window.Audio.prototype = _Audio.prototype;
  var all = [];
  window.addEventListener("message", function (e) {
    var d = e.data; if (!d || d.sky !== "mute") return;
    muted = !!d.v; media(muted); all.forEach(function (a) { a.muted = muted; });
    ctxs.forEach(function (c) { if (muted) c.suspend(); else (window.AudioContext.__resume || c.resume).call(c); });
  });
  window.addEventListener("keydown", function (e) {
    if (e.key === "F9" || e.key === "F11") { e.preventDefault(); parent.postMessage({ sky: "key", key: e.key }, "*"); }
  }, true);
  window.addEventListener("mousemove", function (e) { if (e.clientY < 8 && window.top === window.parent) parent.postMessage({ sky: "edge" }, "*"); }, true);
})();
